<?php
// Database connection parameters
$servername = "localhost"; // Change this if your MySQL server is on a different host
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$dbname = "signup1"; // Change this to the name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process login form submission if it's a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Prepare SQL statement to retrieve user record based on email
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User record found, verify password
        $row = $result->fetch_assoc();
        $hashed_password = $row["password"];

        // Verify password using password_verify() function
        if (password_verify($password, $hashed_password)) {
            // Password is correct, redirect to index.html
            header("Location: index.html");
            exit(); // Stop further execution
        } else {
            // Password is incorrect
            echo "Incorrect password";
        }
    } else {
        // User record not found
        echo "User not found";
    }
}

// Close connection
$conn->close();
?>
