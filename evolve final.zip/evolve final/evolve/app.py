from flask import Flask, request, jsonify,render_template
from nltk.sentiment import SentimentIntensityAnalyzer
import nltk

app = Flask(__name__)
@app.route('/')
def home():
    return render_template('index.html')

# Download NLTK resources
nltk.download('vader_lexicon')

# Initialize sentiment analyzer
sia = SentimentIntensityAnalyzer()

# Dictionary of comforting messages and recommendations
comfort_messages = {
    'positive': ["You're doing great!", "Everything will be okay.", "Stay positive!"],
    'negative': ["I'm here for you.", "It's okay to not be okay.", "You're not alone."],
    'neutral': ["Take a deep breath.", "Focus on the present moment.", "You've got this!"]
}

recommendations = {
    'positive': {
        'books': ['The Alchemist by Paulo Coelho', 'Becoming by Michelle Obama'],
        'movies': ['The Pursuit of Happyness', 'Forrest Gump'],
        'songs': ['Here Comes the Sun by The Beatles', 'Don\'t Stop Believin\' by Journey']
    },
    'negative': {
        'books': ['Reasons to Stay Alive by Matt Haig', 'The Subtle Art of Not Giving a F*ck by Mark Manson'],
        'movies': ['Inside Out', 'Good Will Hunting'],
        'songs': ['Let It Be by The Beatles', 'Hurt by Johnny Cash']
    },
    'neutral': {
        'books': ['The Power of Now by Eckhart Tolle', 'The Four Agreements by Don Miguel Ruiz'],
        'movies': ['Life of Pi', 'The Secret Life of Walter Mitty'],
        'songs': ['Three Little Birds by Bob Marley', 'Imagine by John Lennon']
    }
}

def analyze_emotion(text):
    # Analyze sentiment of text
    sentiment_scores = sia.polarity_scores(text)
    compound_score = sentiment_scores['compound']

    # Determine emotion based on sentiment score
    if compound_score >= 0.05:
        emotion = 'positive'
    elif compound_score <= -0.05:
        emotion = 'negative'
    else:
        emotion = 'neutral'

    return emotion

def get_recommendations_and_comfort(emotion):
    comfort_message = comfort_messages.get(emotion, [])
    recommendation = recommendations.get(emotion, {})
    return comfort_message, recommendation

@app.route('/analyze-text', methods=['POST'])
def analyze_text():
    text = request.json['text']
    emotion = analyze_emotion(text)
    comfort_message, recommendation = get_recommendations_and_comfort(emotion)
    return jsonify({'comfort_message': comfort_message, 'recommendation': recommendation})

if __name__ == '__main__':
    app.run(debug=True)
